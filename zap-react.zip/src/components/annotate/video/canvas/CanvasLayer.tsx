import React from "react";
import './CanvasLayer.css';
import { Stage, Layer, Circle } from "react-konva";

const CanvasLayer = () => {
  return (
    <div className="CanvasLayer">
      <Stage
        width={640}
        height={360}
        onClick={(e) => { 
          alert("comment");
        }}
      >
        <Layer>
          <Circle x={320} y={180} radius={10} fill="red" />
        </Layer>
      </Stage>
    </div>
  );
};

export default CanvasLayer;
